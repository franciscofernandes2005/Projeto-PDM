package com.example.geochallenge;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

public class OfflineGameActivity extends AppCompatActivity {

    private static final int TOTAL_RONDAS = 5;

    private final JSONArray resultados = new JSONArray();

    private final ArrayList<OfflinePlacesRepository.Local> ordem =
            new ArrayList<>();

    private int rondaAtual = 0;
    private int pontosTotais = 0;
    private long partidaEmCursoId;
    private boolean locaisFamosos;

    private boolean terminada = false;
    private boolean mapaAberto = false;
    private Bundle estadoMapaPalpite;

    private OfflinePanoramaView visualizador;
    private FrameLayout container;
    private TextView estado;
    private Button adivinhar;

    private ActivityResultLauncher<Intent> abrirMapa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_offline_game);

        container = findViewById(
                R.id.offlinePanoramaContainer
        );

        estado = findViewById(
                R.id.txtOfflineEstado
        );

        adivinhar = findViewById(
                R.id.btnOfflineAdivinhar
        );

        Button mais = findViewById(
                R.id.btnOfflineZoomMais
        );

        Button menos = findViewById(
                R.id.btnOfflineZoomMenos
        );

        // Carregar os 20 locais disponíveis.
        try {
            partidaEmCursoId = getIntent().getLongExtra(
                    "partidaEmCursoId", 0
            );
            locaisFamosos = getIntent().getBooleanExtra(
                    "locaisFamosos", false
            );
            ArrayList<OfflinePlacesRepository.Local> locais =
                    locaisFamosos
                            ? OfflinePlacesRepository.carregarLocaisFamosos(this)
                            : OfflinePlacesRepository.carregar(this);

            if (partidaEmCursoId > 0) {
                restaurarPartida(locais);
            } else {
                ordem.addAll(locais);
                Collections.shuffle(ordem);
            }

        } catch (Exception e) {

            new AlertDialog.Builder(this)
                    .setTitle(R.string.offline_erro_titulo)
                    .setMessage(
                            getString(
                                    R.string.offline_erro_ficheiros
                            ) + "\n" + e.getMessage()
                    )
                    .setPositiveButton(
                            R.string.offline_sair,
                            (dialog, which) -> finish()
                    )
                    .setCancelable(false)
                    .show();

            return;
        }

        // Receber o resultado de cada ronda.
        abrirMapa = registerForActivityResult(
                new ActivityResultContracts
                        .StartActivityForResult(),

                result -> {

                    mapaAberto = false;

                    if (result.getResultCode() == Activity.RESULT_OK
                            && result.getData() != null) {

                        estadoMapaPalpite = null;
                        guardarResultado(
                                result.getData()
                        );
                    } else if (result.getData() != null
                            && result.getData().getExtras() != null) {
                        estadoMapaPalpite = new Bundle(
                                result.getData().getExtras()
                        );
                    }
                }
        );

        // Abrir o mapa para adivinhar.
        adivinhar.setOnClickListener(v -> {

            if (terminada || mapaAberto ||
                    rondaAtual >= TOTAL_RONDAS) {
                return;
            }

            OfflinePlacesRepository.Local local =
                    ordem.get(rondaAtual);

            Intent intent = new Intent(
                    OfflineGameActivity.this,
                    OfflineGuessActivity.class
            );

            intent.putExtra(
                    "latitude",
                    local.latitude
            );

            intent.putExtra(
                    "longitude",
                    local.longitude
            );

            intent.putExtra(
                    "ronda",
                    rondaAtual + 1
            );
            if (estadoMapaPalpite != null) {
                intent.putExtras(estadoMapaPalpite);
            }

            mapaAberto = true;

            abrirMapa.launch(intent);
        });

        // Controlos de zoom.
        mais.setOnClickListener(v -> {

            if (visualizador != null) {
                visualizador.aproximar();
            }
        });

        menos.setOnClickListener(v -> {

            if (visualizador != null) {
                visualizador.afastar();
            }
        });

        findViewById(R.id.btnOfflineVoltarMenu).setOnClickListener(v -> {
            guardarPartidaEmCurso();
            voltarAoMenuPrincipal();
        });

        mostrarRonda();
    }

    private void restaurarPartida(
            ArrayList<OfflinePlacesRepository.Local> locais) throws Exception {
        GameDatabaseHelper db = new GameDatabaseHelper(this);
        try (android.database.Cursor cursor =
                     db.obterPartidaEmCurso(partidaEmCursoId)) {
            if (!cursor.moveToFirst()) {
                throw new IllegalStateException(
                        "A partida em curso já não existe."
                );
            }

            JSONObject estado = new JSONObject(
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("estado")
                    )
            );

            JSONArray ordemGuardada = estado.getJSONArray("ordem");
            for (int i = 0; i < ordemGuardada.length(); i++) {
                int id = ordemGuardada.getInt(i);
                for (OfflinePlacesRepository.Local local : locais) {
                    if (local.id == id) {
                        ordem.add(local);
                        break;
                    }
                }
            }

            if (ordem.size() != ordemGuardada.length()) {
                throw new IllegalStateException(
                        "Não foi possível restaurar a ordem dos locais."
                );
            }

            rondaAtual = estado.getInt("indiceRonda");
            pontosTotais = estado.getInt("pontosTotais");
            JSONArray rondasGuardadas = estado.getJSONArray("resultados");
            for (int i = 0; i < rondasGuardadas.length(); i++) {
                resultados.put(rondasGuardadas.getJSONObject(i));
            }
        } finally {
            db.close();
        }
    }

    private void mostrarRonda() {

        if (terminada || rondaAtual >= TOTAL_RONDAS) {
            return;
        }

        if (visualizador != null) {

            visualizador.onPause();
            container.removeView(visualizador);
        }

        OfflinePlacesRepository.Local local =
                ordem.get(rondaAtual);

        visualizador = new OfflinePanoramaView(
                this,
                local.caminhoImagem
        );

        container.addView(
                visualizador,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                )
        );

        adivinhar.setEnabled(true);

        estado.setText(
                getString(
                        R.string.offline_ronda_estado,
                        rondaAtual + 1,
                        TOTAL_RONDAS,
                        pontosTotais
                )
        );
        guardarPartidaEmCurso();
    }

    private void guardarPartidaEmCurso() {
        if (terminada || ordem.isEmpty()) {
            return;
        }

        try {
            JSONArray ordemJson = new JSONArray();
            for (OfflinePlacesRepository.Local local : ordem) {
                ordemJson.put(local.id);
            }

            JSONObject estadoJson = new JSONObject();
            estadoJson.put("indiceRonda", rondaAtual);
            estadoJson.put("rondaAtual", rondaAtual + 1);
            estadoJson.put("pontosTotais", pontosTotais);
            estadoJson.put("ordem", ordemJson);
            estadoJson.put("resultados", new JSONArray(resultados.toString()));

            GameDatabaseHelper db = new GameDatabaseHelper(this);
            try {
                partidaEmCursoId = db.guardarPartidaEmCurso(
                        partidaEmCursoId,
                        nomeModo(),
                        estadoJson
                );
            } finally {
                db.close();
            }
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    R.string.offline_erro_guardar_ronda,
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void voltarAoMenuPrincipal() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void guardarResultado(Intent data) {

        if (terminada || rondaAtual >= TOTAL_RONDAS) {
            return;
        }

        OfflinePlacesRepository.Local local =
                ordem.get(rondaAtual);

        int pontos = Math.max(
                0,
                Math.min(
                        5000,
                        data.getIntExtra("pontos", 0)
                )
        );

        double distancia = data.getDoubleExtra(
                "distancia",
                0
        );

        try {

            JSONObject registo = new JSONObject();

            registo.put("ronda", rondaAtual + 1);
            registo.put("localId", local.id);
            registo.put("nome", local.nome);
            registo.put("pais", local.pais);

            registo.put(
                    "latitudeCorreta",
                    local.latitude
            );

            registo.put(
                    "longitudeCorreta",
                    local.longitude
            );

            registo.put(
                    "latitudePalpite",
                    data.getDoubleExtra(
                            "latitudePalpite", 0
                    )
            );

            registo.put(
                    "longitudePalpite",
                    data.getDoubleExtra(
                            "longitudePalpite", 0
                    )
            );

            registo.put("distancia", distancia);
            registo.put("pontos", pontos);

            resultados.put(registo);

            pontosTotais += pontos;
            rondaAtual++;

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    R.string.offline_erro_guardar_ronda,
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (rondaAtual == TOTAL_RONDAS) {
            terminarPartida();
        } else {
            mostrarRonda();
        }
    }

    private void terminarPartida() {

        terminada = true;

        adivinhar.setEnabled(false);

        GameDatabaseHelper db =
                new GameDatabaseHelper(this);

        long id = db.guardarPartida(
                nomeModo(),
                pontosTotais,
                resultados
        );
        db.eliminarPartidaEmCurso(partidaEmCursoId);
        db.close();

        String mensagem = String.format(
                Locale.getDefault(),
                "%s\n%s",
                getString(
                        R.string.offline_fim_mensagem,
                        pontosTotais
                ),
                id >= 0
                        ? getString(R.string.offline_guardado)
                        : getString(R.string.offline_nao_guardado)
        );

        new AlertDialog.Builder(this)
                .setTitle(R.string.offline_fim_titulo)
                .setMessage(mensagem)
                .setPositiveButton(
                        R.string.offline_voltar_menu,
                        (dialog, which) -> finish()
                )
                .setCancelable(false)
                .show();
    }

    private String nomeModo() {
        return locaisFamosos ? "Locais Famosos" : "Mundo Offline";
    }

    @Override
    protected void onPause() {
        super.onPause();

        guardarPartidaEmCurso();
        if (visualizador != null) {
            visualizador.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (visualizador != null) {
            visualizador.onResume();
        }
    }
}
