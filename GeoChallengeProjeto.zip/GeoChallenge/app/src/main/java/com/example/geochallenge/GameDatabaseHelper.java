package com.example.geochallenge;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class GameDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "geochallenge.db";
    private static final int DB_VERSION = 2;

    public static final class EstatisticasModo {
        public final int partidas;
        public final long pontosTotais;
        public final double distanciaTotalKm;
        public final int rondasComDistancia;

        private EstatisticasModo() {
            partidas = 0;
            pontosTotais = 0;
            distanciaTotalKm = 0;
            rondasComDistancia = 0;
        }

        private EstatisticasModo(
                int partidas,
                long pontosTotais,
                double distanciaTotalKm,
                int rondasComDistancia) {
            this.partidas = partidas;
            this.pontosTotais = pontosTotais;
            this.distanciaTotalKm = distanciaTotalKm;
            this.rondasComDistancia = rondasComDistancia;
        }

        public double pontuacaoMedia() {
            return partidas == 0 ? 0 : (double) pontosTotais / partidas;
        }

        public double distanciaMediaKm() {
            return rondasComDistancia == 0
                    ? 0
                    : distanciaTotalKm / rondasComDistancia;
        }
    }

    public static final class Estatisticas {
        public final int partidas;
        public final long pontosTotais;
        public final double distanciaTotalKm;
        public final int rondasComDistancia;
        public final Map<String, EstatisticasModo> porModo;

        private Estatisticas(
                int partidas,
                long pontosTotais,
                double distanciaTotalKm,
                int rondasComDistancia,
                Map<String, EstatisticasModo> porModo) {
            this.partidas = partidas;
            this.pontosTotais = pontosTotais;
            this.distanciaTotalKm = distanciaTotalKm;
            this.rondasComDistancia = rondasComDistancia;
            this.porModo = porModo;
        }

        public double pontuacaoMedia() {
            return partidas == 0 ? 0 : (double) pontosTotais / partidas;
        }

        public double distanciaMediaKm() {
            return rondasComDistancia == 0
                    ? 0
                    : distanciaTotalKm / rondasComDistancia;
        }
    }

    public GameDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        criarTabelaPartidas(db);
        criarTabelaPartidasEmCurso(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            criarTabelaPartidasEmCurso(db);
        }
    }

    private void criarTabelaPartidas(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS partidas (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "data TEXT NOT NULL," +
                        "modo TEXT NOT NULL," +
                        "pontuacao INTEGER NOT NULL," +
                        "rondas INTEGER NOT NULL," +
                        "detalhes TEXT NOT NULL)"
        );
    }

    private void criarTabelaPartidasEmCurso(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS partidas_em_curso (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "data TEXT NOT NULL," +
                        "modo TEXT NOT NULL," +
                        "estado TEXT NOT NULL)"
        );
    }

    public long guardarPartida(
            String modo,
            int pontos,
            JSONArray detalhes) {

        String data = new SimpleDateFormat(
                "dd/MM/yyyy HH:mm",
                Locale.getDefault()
        ).format(new Date());

        ContentValues valores = new ContentValues();

        valores.put("data", data);
        valores.put("modo", modo);
        valores.put("pontuacao", pontos);
        valores.put("rondas", detalhes.length());
        valores.put("detalhes", detalhes.toString());

        SQLiteDatabase db = getWritableDatabase();

        return db.insert("partidas", null, valores);
    }

    public Cursor listarPartidas() {
        return getReadableDatabase().rawQuery(
                "SELECT * FROM partidas ORDER BY id DESC",
                null
        );
    }

    public long guardarPartidaEmCurso(
            long id,
            String modo,
            JSONObject estado) {

        String data = new SimpleDateFormat(
                "dd/MM/yyyy HH:mm",
                Locale.getDefault()
        ).format(new Date());

        ContentValues valores = new ContentValues();
        valores.put("data", data);
        valores.put("modo", modo);
        valores.put("estado", estado.toString());

        SQLiteDatabase db = getWritableDatabase();
        if (id > 0) {
            int atualizados = db.update(
                    "partidas_em_curso",
                    valores,
                    "id = ?",
                    new String[]{String.valueOf(id)}
            );
            if (atualizados > 0) {
                return id;
            }
        }
        return db.insertOrThrow("partidas_em_curso", null, valores);
    }

    public Cursor listarPartidasEmCurso() {
        return getReadableDatabase().rawQuery(
                "SELECT * FROM partidas_em_curso ORDER BY id DESC",
                null
        );
    }

    public Cursor obterPartidaEmCurso(long id) {
        return getReadableDatabase().rawQuery(
                "SELECT * FROM partidas_em_curso WHERE id = ?",
                new String[]{String.valueOf(id)}
        );
    }

    public boolean eliminarPartidaEmCurso(long id) {
        return getWritableDatabase().delete(
                "partidas_em_curso",
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    public boolean eliminarPartida(long id) {
        return getWritableDatabase().delete(
                "partidas",
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    public int contarPartidas() {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM partidas",
                null
        );

        int total = 0;

        if (cursor.moveToFirst()) {
            total = cursor.getInt(0);
        }

        cursor.close();
        return total;
    }

    public int melhorPontuacao() {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT MAX(pontuacao) FROM partidas",
                null
        );

        int melhor = 0;

        if (cursor.moveToFirst() && !cursor.isNull(0)) {
            melhor = cursor.getInt(0);
        }

        cursor.close();
        return melhor;
    }

    public Estatisticas obterEstatisticas() {
        int totalPartidas = 0;
        long totalPontos = 0;
        double distanciaTotalKm = 0;
        int rondasComDistancia = 0;

        Map<String, AcumuladorModo> acumuladores = new LinkedHashMap<>();

        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT modo, pontuacao, detalhes FROM partidas ORDER BY id DESC",
                null
        )) {
            while (cursor.moveToNext()) {
                String modo = cursor.getString(
                        cursor.getColumnIndexOrThrow("modo")
                );
                if (modo == null || modo.trim().isEmpty()) {
                    modo = "Outro";
                }

                int pontos = cursor.getInt(
                        cursor.getColumnIndexOrThrow("pontuacao")
                );
                totalPartidas++;
                totalPontos += pontos;

                AcumuladorModo acumulador = acumuladores.get(modo);
                if (acumulador == null) {
                    acumulador = new AcumuladorModo();
                    acumuladores.put(modo, acumulador);
                }
                acumulador.partidas++;
                acumulador.pontosTotais += pontos;

                try {
                    JSONArray rondas = new JSONArray(cursor.getString(
                            cursor.getColumnIndexOrThrow("detalhes")
                    ));
                    for (int i = 0; i < rondas.length(); i++) {
                        JSONObject ronda = rondas.optJSONObject(i);
                        if (ronda == null || !ronda.has("distancia")) {
                            continue;
                        }

                        double distancia = ronda.optDouble("distancia", -1);
                        if (Double.isNaN(distancia)
                                || Double.isInfinite(distancia)
                                || distancia < 0) {
                            continue;
                        }

                        distanciaTotalKm += distancia;
                        rondasComDistancia++;
                        acumulador.distanciaTotalKm += distancia;
                        acumulador.rondasComDistancia++;
                    }
                } catch (org.json.JSONException e) {
                    // Partidas antigas sem detalhes válidos continuam a contar para a pontuação.
                }
            }
        }

        Map<String, EstatisticasModo> porModo = new LinkedHashMap<>();
        for (Map.Entry<String, AcumuladorModo> entrada : acumuladores.entrySet()) {
            AcumuladorModo acumulador = entrada.getValue();
            porModo.put(
                    entrada.getKey(),
                    new EstatisticasModo(
                            acumulador.partidas,
                            acumulador.pontosTotais,
                            acumulador.distanciaTotalKm,
                            acumulador.rondasComDistancia
                    )
            );
        }

        return new Estatisticas(
                totalPartidas,
                totalPontos,
                distanciaTotalKm,
                rondasComDistancia,
                porModo
        );
    }

    private static final class AcumuladorModo {
        int partidas;
        long pontosTotais;
        double distanciaTotalKm;
        int rondasComDistancia;
    }
}
