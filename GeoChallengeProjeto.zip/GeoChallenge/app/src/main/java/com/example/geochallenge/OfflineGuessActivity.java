package com.example.geochallenge;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class OfflineGuessActivity extends AppCompatActivity
        implements OnMapReadyCallback {

    private GoogleMap googleMap;
    private LatLng correta;
    private LatLng palpite;
    private Marker marcadorPalpite;

    private TextView info;
    private TextView resultado;
    private Button confirmar;
    private Button voltar;

    private int ronda;
    private boolean respondeu = false;

    private static final String EXTRA_MAP_CENTER_LATITUDE =
            "mapCenterLatitude";
    private static final String EXTRA_MAP_CENTER_LONGITUDE =
            "mapCenterLongitude";
    private static final String EXTRA_MAP_ZOOM = "mapZoom";
    private static final String EXTRA_HAS_GUESS = "mapHasGuess";
    private static final String EXTRA_GUESS_LATITUDE = "mapGuessLatitude";
    private static final String EXTRA_GUESS_LONGITUDE = "mapGuessLongitude";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline_guess);

        TextView titulo = findViewById(R.id.txtOfflineTituloMapa);
        info = findViewById(R.id.txtOfflineInfo);
        resultado = findViewById(R.id.txtOfflineResultado);
        confirmar = findViewById(R.id.btnOfflineConfirmar);
        voltar = findViewById(R.id.btnOfflineVoltar);

        ronda = getIntent().getIntExtra("ronda", 1);
        correta = new LatLng(
                getIntent().getDoubleExtra("latitude", 0),
                getIntent().getDoubleExtra("longitude", 0)
        );

        titulo.setText(getString(R.string.guess_title, ronda));
        confirmar.setEnabled(false);

        voltar.setOnClickListener(v -> devolverAoJogo());
        confirmar.setOnClickListener(v -> {
            if (respondeu) {
                finish();
            } else {
                confirmarPalpite();
            }
        });

        SupportMapFragment fragment =
                (SupportMapFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.offlineMapaContainer);

        if (fragment != null) {
            fragment.getMapAsync(this);
        } else {
            Toast.makeText(
                    this,
                    R.string.offline_erro_mapa,
                    Toast.LENGTH_LONG
            ).show();
            confirmar.setEnabled(false);
        }
    }

    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;

        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        googleMap.getUiSettings().setZoomGesturesEnabled(true);
        googleMap.getUiSettings().setScrollGesturesEnabled(true);
        googleMap.getUiSettings().setRotateGesturesEnabled(false);
        googleMap.getUiSettings().setTiltGesturesEnabled(false);

        boolean estadoAnterior = getIntent().hasExtra(
                EXTRA_MAP_CENTER_LATITUDE
        );
        LatLng centro = estadoAnterior
                ? new LatLng(
                        getIntent().getDoubleExtra(
                                EXTRA_MAP_CENTER_LATITUDE, 15
                        ),
                        getIntent().getDoubleExtra(
                                EXTRA_MAP_CENTER_LONGITUDE, 0
                        )
                )
                : new LatLng(15, 0);
        float zoom = getIntent().getFloatExtra(EXTRA_MAP_ZOOM, 2f);
        googleMap.moveCamera(
                CameraUpdateFactory.newLatLngZoom(centro, zoom)
        );

        if (getIntent().getBooleanExtra(EXTRA_HAS_GUESS, false)) {
            palpite = new LatLng(
                    getIntent().getDoubleExtra(EXTRA_GUESS_LATITUDE, 0),
                    getIntent().getDoubleExtra(EXTRA_GUESS_LONGITUDE, 0)
            );
            marcadorPalpite = googleMap.addMarker(
                    new MarkerOptions()
                            .position(palpite)
                            .title("O teu palpite")
                            .icon(BitmapDescriptorFactory.defaultMarker(
                                    BitmapDescriptorFactory.HUE_RED))
            );
            confirmar.setEnabled(true);
            info.setText(R.string.guess_selected);
        }

        googleMap.setOnMapClickListener(local -> {
            if (respondeu) {
                return;
            }

            palpite = local;

            if (marcadorPalpite != null) {
                marcadorPalpite.remove();
            }

            marcadorPalpite = googleMap.addMarker(
                    new MarkerOptions()
                            .position(palpite)
                            .title("O teu palpite")
                            .icon(BitmapDescriptorFactory.defaultMarker(
                                    BitmapDescriptorFactory.HUE_RED))
            );

            confirmar.setEnabled(true);
            info.setText(R.string.guess_selected);
        });
    }

    private void confirmarPalpite() {
        if (palpite == null || respondeu) {
            Toast.makeText(
                    this,
                    "Seleciona primeiro um local",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        respondeu = true;

        float[] distancias = new float[1];
        Location.distanceBetween(
                palpite.latitude,
                palpite.longitude,
                correta.latitude,
                correta.longitude,
                distancias
        );

        double distanciaKm = distancias[0] / 1000.0;
        int pontos = (int) Math.round(
                5000 * Math.exp(-distanciaKm / 2000.0)
        );
        pontos = Math.max(0, Math.min(5000, pontos));

        googleMap.addMarker(
                new MarkerOptions()
                        .position(correta)
                        .title("Localização correta")
                        .icon(BitmapDescriptorFactory.defaultMarker(
                                BitmapDescriptorFactory.HUE_GREEN))
        );

        googleMap.addPolyline(
                new PolylineOptions()
                        .add(palpite, correta)
                        .width(5f)
                        .color(Color.RED)
        );

        LatLngBounds limites = new LatLngBounds.Builder()
                .include(palpite)
                .include(correta)
                .build();
        googleMap.animateCamera(
                CameraUpdateFactory.newLatLngBounds(limites, 100)
        );

        resultado.setText(
                getString(R.string.guess_result, distanciaKm, pontos)
        );
        resultado.setVisibility(View.VISIBLE);
        info.setVisibility(View.GONE);

        confirmar.setText(
                ronda == 5
                        ? R.string.offline_terminar
                        : R.string.offline_proxima
        );
        confirmar.setEnabled(true);
        voltar.setVisibility(View.GONE);

        Intent resposta = new Intent();
        resposta.putExtra("distancia", distanciaKm);
        resposta.putExtra("pontos", pontos);
        resposta.putExtra("latitudePalpite", palpite.latitude);
        resposta.putExtra("longitudePalpite", palpite.longitude);
        setResult(Activity.RESULT_OK, resposta);
    }

    private void devolverAoJogo() {
        if (respondeu || googleMap == null) {
            finish();
            return;
        }

        CameraPosition camera = googleMap.getCameraPosition();
        Intent estado = new Intent();
        estado.putExtra(
                EXTRA_MAP_CENTER_LATITUDE,
                camera.target.latitude
        );
        estado.putExtra(
                EXTRA_MAP_CENTER_LONGITUDE,
                camera.target.longitude
        );
        estado.putExtra(EXTRA_MAP_ZOOM, camera.zoom);
        estado.putExtra(EXTRA_HAS_GUESS, palpite != null);
        if (palpite != null) {
            estado.putExtra(EXTRA_GUESS_LATITUDE, palpite.latitude);
            estado.putExtra(EXTRA_GUESS_LONGITUDE, palpite.longitude);
        }
        setResult(Activity.RESULT_CANCELED, estado);
        finish();
    }

    @Override
    public void onBackPressed() {
        devolverAoJogo();
    }
}
