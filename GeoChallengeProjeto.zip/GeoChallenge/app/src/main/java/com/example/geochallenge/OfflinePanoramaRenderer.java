package com.example.geochallenge;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class OfflinePanoramaRenderer
        implements GLSurfaceView.Renderer {

    private final Context context;
    private final String imagem;

    private final FloatBuffer vertices;
    private final ShortBuffer indices;

    private int quantidadeIndices;
    private int programa;
    private int textura;

    private int largura = 1;
    private int altura = 1;

    private float yaw = 0;
    private float pitch = 0;
    private float fov = 70;

    private final float[] projecao = new float[16];
    private final float[] vista = new float[16];
    private final float[] mvp = new float[16];

    public OfflinePanoramaRenderer(
            Context context,
            String imagem) {

        this.context = context.getApplicationContext();
        this.imagem = imagem;

        int linhas = 40;
        int colunas = 80;

        float[] dados = new float[
                (linhas + 1) * (colunas + 1) * 5
                ];

        short[] faces = new short[
                linhas * colunas * 6
                ];

        int p = 0;
        int k = 0;

        for (int i = 0; i <= linhas; i++) {

            double latitude = Math.PI * i / linhas;

            for (int j = 0; j <= colunas; j++) {

                double longitude =
                        2 * Math.PI * j / colunas;

                dados[p++] = (float) (
                        Math.sin(latitude) * Math.sin(longitude)
                );

                dados[p++] = (float) Math.cos(latitude);

                dados[p++] = (float) (
                        -Math.sin(latitude) * Math.cos(longitude)
                );

                dados[p++] = (float) j / colunas;
                dados[p++] = (float) i / linhas;
            }
        }

        for (int i = 0; i < linhas; i++) {

            for (int j = 0; j < colunas; j++) {

                short a = (short) (
                        i * (colunas + 1) + j
                );

                short b = (short) (
                        a + colunas + 1
                );

                faces[k++] = a;
                faces[k++] = b;
                faces[k++] = (short) (a + 1);

                faces[k++] = (short) (a + 1);
                faces[k++] = b;
                faces[k++] = (short) (b + 1);
            }
        }

        vertices = ByteBuffer
                .allocateDirect(dados.length * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();

        vertices.put(dados).position(0);

        indices = ByteBuffer
                .allocateDirect(faces.length * 2)
                .order(ByteOrder.nativeOrder())
                .asShortBuffer();

        indices.put(faces).position(0);

        quantidadeIndices = faces.length;
    }

    public synchronized void rodar(float dx, float dy) {

        yaw -= dx;

        pitch = Math.max(
                -85,
                Math.min(85, pitch + dy)
        );
    }

    public synchronized void mudarZoom(float fator) {

        if (fator > 0) {

            fov = Math.max(
                    30,
                    Math.min(90, fov / fator)
            );
        }
    }

    private int criarShader(int tipo, String codigo) {

        int shader = GLES20.glCreateShader(tipo);

        GLES20.glShaderSource(shader, codigo);
        GLES20.glCompileShader(shader);

        return shader;
    }

    @Override
    public void onSurfaceCreated(
            GL10 gl,
            EGLConfig config) {

        String vertexShader =
                "attribute vec3 aPos;" +
                        "attribute vec2 aUV;" +
                        "uniform mat4 uMVP;" +
                        "varying vec2 vUV;" +
                        "void main() {" +
                        "vUV = aUV;" +
                        "gl_Position = uMVP * vec4(aPos, 1.0);" +
                        "}";

        String fragmentShader =
                "precision mediump float;" +
                        "varying vec2 vUV;" +
                        "uniform sampler2D uTex;" +
                        "void main() {" +
                        "gl_FragColor = texture2D(uTex, vUV);" +
                        "}";

        int vertex = criarShader(
                GLES20.GL_VERTEX_SHADER,
                vertexShader
        );

        int fragment = criarShader(
                GLES20.GL_FRAGMENT_SHADER,
                fragmentShader
        );

        programa = GLES20.glCreateProgram();

        GLES20.glAttachShader(programa, vertex);
        GLES20.glAttachShader(programa, fragment);

        GLES20.glLinkProgram(programa);

        GLES20.glDeleteShader(vertex);
        GLES20.glDeleteShader(fragment);

        int[] texturas = new int[1];

        GLES20.glGenTextures(1, texturas, 0);
        textura = texturas[0];

        GLES20.glBindTexture(
                GLES20.GL_TEXTURE_2D,
                textura
        );

        GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MIN_FILTER,
                GLES20.GL_LINEAR
        );

        GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MAG_FILTER,
                GLES20.GL_LINEAR
        );

        GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_WRAP_S,
                GLES20.GL_CLAMP_TO_EDGE
        );

        GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_WRAP_T,
                GLES20.GL_CLAMP_TO_EDGE
        );

        String caminho = imagem.contains("/")
                ? imagem
                : "offline_360/" + imagem;

        try (InputStream entrada =
                     context.getAssets().open(caminho)) {

            Bitmap bitmap =
                    BitmapFactory.decodeStream(entrada);

            if (bitmap == null) {
                throw new IllegalStateException(
                        "Imagem inválida: " + imagem
                );
            }

            GLUtils.texImage2D(
                    GLES20.GL_TEXTURE_2D,
                    0,
                    bitmap,
                    0
            );

            bitmap.recycle();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Erro ao carregar imagem: " + imagem,
                    e
            );
        }

        GLES20.glDisable(GLES20.GL_CULL_FACE);
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
    }

    @Override
    public void onSurfaceChanged(
            GL10 gl,
            int width,
            int height) {

        largura = Math.max(1, width);
        altura = Math.max(1, height);

        GLES20.glViewport(
                0,
                0,
                largura,
                altura
        );
    }

    @Override
    public void onDrawFrame(GL10 gl) {

        GLES20.glClearColor(0, 0, 0, 1);

        GLES20.glClear(
                GLES20.GL_COLOR_BUFFER_BIT
        );

        float horizontal;
        float vertical;
        float zoom;

        synchronized (this) {

            horizontal = yaw;
            vertical = pitch;
            zoom = fov;
        }

        Matrix.perspectiveM(
                projecao,
                0,
                zoom,
                (float) largura / altura,
                0.1f,
                10f
        );

        double ry = Math.toRadians(horizontal);
        double rp = Math.toRadians(vertical);

        Matrix.setLookAtM(
                vista,
                0,
                0, 0, 0,
                (float) (Math.sin(ry) * Math.cos(rp)),
                (float) Math.sin(rp),
                (float) (-Math.cos(ry) * Math.cos(rp)),
                0, 1, 0
        );

        Matrix.multiplyMM(
                mvp,
                0,
                projecao,
                0,
                vista,
                0
        );

        GLES20.glUseProgram(programa);

        int pos = GLES20.glGetAttribLocation(
                programa,
                "aPos"
        );

        int uv = GLES20.glGetAttribLocation(
                programa,
                "aUV"
        );

        int matriz = GLES20.glGetUniformLocation(
                programa,
                "uMVP"
        );

        int tex = GLES20.glGetUniformLocation(
                programa,
                "uTex"
        );

        vertices.position(0);

        GLES20.glEnableVertexAttribArray(pos);

        GLES20.glVertexAttribPointer(
                pos,
                3,
                GLES20.GL_FLOAT,
                false,
                20,
                vertices
        );

        vertices.position(3);

        GLES20.glEnableVertexAttribArray(uv);

        GLES20.glVertexAttribPointer(
                uv,
                2,
                GLES20.GL_FLOAT,
                false,
                20,
                vertices
        );

        GLES20.glUniformMatrix4fv(
                matriz,
                1,
                false,
                mvp,
                0
        );

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);

        GLES20.glBindTexture(
                GLES20.GL_TEXTURE_2D,
                textura
        );

        GLES20.glUniform1i(tex, 0);

        indices.position(0);

        GLES20.glDrawElements(
                GLES20.GL_TRIANGLES,
                quantidadeIndices,
                GLES20.GL_UNSIGNED_SHORT,
                indices
        );

        GLES20.glDisableVertexAttribArray(pos);
        GLES20.glDisableVertexAttribArray(uv);
    }
}
