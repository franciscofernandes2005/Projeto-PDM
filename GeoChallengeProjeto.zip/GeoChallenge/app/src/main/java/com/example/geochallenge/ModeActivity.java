package com.example.geochallenge;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ModeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);

        Button btnOnline = findViewById(R.id.btnModoOnline);
        Button btnOffline = findViewById(R.id.btnModoOffline);
        Button btnLocaisFamosos = findViewById(
                R.id.btnModoLocaisFamosos
        );

        btnOnline.setOnClickListener(v -> {
            Intent intent = new Intent(
                    ModeActivity.this,
                    OnlineGameActivity.class
            );
            startActivity(intent);
        });

        btnOffline.setOnClickListener(v -> {
            Intent intent = new Intent(
                    ModeActivity.this,
                    OfflineGameActivity.class
            );
            startActivity(intent);
        });

        btnLocaisFamosos.setOnClickListener(v -> {
            Intent intent = new Intent(
                    ModeActivity.this,
                    OfflineGameActivity.class
            );
            intent.putExtra("locaisFamosos", true);
            startActivity(intent);
        });
    }
}
