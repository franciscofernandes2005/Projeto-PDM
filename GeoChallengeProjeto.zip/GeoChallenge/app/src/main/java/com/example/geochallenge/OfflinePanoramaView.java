package com.example.geochallenge;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class OfflinePanoramaView extends GLSurfaceView {

    private final OfflinePanoramaRenderer renderer;

    private float ultimoX;
    private float ultimoY;
    private float distanciaAnterior;

    private boolean aFazerZoom = false;

    public OfflinePanoramaView(
            Context context,
            String imagem) {

        super(context);

        setEGLContextClientVersion(2);

        renderer = new OfflinePanoramaRenderer(
                context,
                imagem
        );

        setRenderer(renderer);

        setRenderMode(
                GLSurfaceView.RENDERMODE_WHEN_DIRTY
        );
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch (event.getActionMasked()) {

            case MotionEvent.ACTION_DOWN:

                ultimoX = event.getX();
                ultimoY = event.getY();

                aFazerZoom = false;

                return true;

            case MotionEvent.ACTION_POINTER_DOWN:

                if (event.getPointerCount() > 1) {
                    distanciaAnterior =
                            calcularDistancia(event);

                    aFazerZoom = true;
                }

                return true;

            case MotionEvent.ACTION_MOVE:

                if (event.getPointerCount() >= 2) {

                    float distancia =
                            calcularDistancia(event);

                    if (distanciaAnterior > 0 &&
                            distancia > 0) {

                        renderer.mudarZoom(
                                distancia / distanciaAnterior
                        );

                        requestRender();
                    }

                    distanciaAnterior = distancia;

                } else if (!aFazerZoom) {

                    float x = event.getX();
                    float y = event.getY();

                    renderer.rodar(
                            (x - ultimoX) * 0.18f,
                            (y - ultimoY) * 0.18f
                    );

                    ultimoX = x;
                    ultimoY = y;

                    requestRender();
                }

                return true;

            case MotionEvent.ACTION_POINTER_UP:

                aFazerZoom = true;
                return true;

            case MotionEvent.ACTION_UP:

                aFazerZoom = false;
                performClick();
                return true;

            case MotionEvent.ACTION_CANCEL:

                aFazerZoom = false;
                return true;

            default:
                return true;
        }
    }

    private float calcularDistancia(MotionEvent event) {

        float dx = event.getX(0) - event.getX(1);
        float dy = event.getY(0) - event.getY(1);

        return (float) Math.hypot(dx, dy);
    }

    public void aproximar() {

        renderer.mudarZoom(1.2f);
        requestRender();
    }

    public void afastar() {

        renderer.mudarZoom(1 / 1.2f);
        requestRender();
    }

    @Override
    public boolean performClick() {

        super.performClick();
        return true;
    }
}
