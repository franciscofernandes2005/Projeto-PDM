package com.example.geochallenge;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.SupportStreetViewPanoramaFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaCamera;
import com.google.android.gms.maps.model.StreetViewPanoramaLocation;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

public class OnlineGameActivity extends AppCompatActivity
        implements OnStreetViewPanoramaReadyCallback {

    private static final int TOTAL_RONDAS = 5;

    private StreetViewPanorama panorama;

    private Button btnAdivinhar;
    private Button btnZoomMais;
    private Button btnZoomMenos;
    private TextView txtEstado;
    private TextView txtCompassNeedle;

    private final ArrayList<JSONObject> locais =
            new ArrayList<>();

    private final JSONArray resultados =
            new JSONArray();

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private Runnable timeoutAtual;

    private int indice = 0;
    private int rondaAtual = 1;
    private int pontosTotais = 0;

    private boolean localPronto = false;
    private boolean terminada = false;
    private boolean aCarregar = false;
    private boolean retomarRondaAtual = false;

    private LatLng localizacaoInicial;
    private LatLng coordenadaEsperada;
    private String panoAtualId;
    private long partidaEmCursoId;
    private Bundle estadoMapaPalpite;

    private ActivityResultLauncher<Intent> abrirMapa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_online_game);

        btnAdivinhar = findViewById(
                R.id.btnAdivinharOnline
        );

        btnZoomMais = findViewById(
                R.id.btnZoomMais
        );

        btnZoomMenos = findViewById(
                R.id.btnZoomMenos
        );

        txtEstado = findViewById(
                R.id.txtEstadoOnline
        );

        txtCompassNeedle = findViewById(
                R.id.txtCompassNeedle
        );

        btnAdivinhar.setEnabled(false);

        if (!carregarLocais()) {
            return;
        }

        partidaEmCursoId = getIntent().getLongExtra(
                "partidaEmCursoId", 0
        );
        if (partidaEmCursoId > 0) {
            if (!restaurarPartida()) {
                mostrarErro("Não foi possível restaurar esta partida.");
                return;
            }
        } else {
            Collections.shuffle(locais);
        }

        abrirMapa = registerForActivityResult(
                new ActivityResultContracts
                        .StartActivityForResult(),
                resultado -> {
                    if (resultado.getData() == null) {
                        return;
                    }

                    if (resultado.getResultCode() == Activity.RESULT_OK) {
                        estadoMapaPalpite = null;
                        guardarRonda(resultado.getData());
                    } else {
                        estadoMapaPalpite = resultado.getData().getExtras() == null
                                ? null
                                : new Bundle(resultado.getData().getExtras());
                    }
                }
        );

        btnAdivinhar.setOnClickListener(
                v -> abrirPalpite()
        );

        btnZoomMais.setOnClickListener(
                v -> alterarZoom(0.5f)
        );

        btnZoomMenos.setOnClickListener(
                v -> alterarZoom(-0.5f)
        );

        findViewById(R.id.btnVoltarMenuOnline).setOnClickListener(v -> {
            guardarPartidaEmCurso();
            voltarAoMenuPrincipal();
        });

        SupportStreetViewPanoramaFragment fragment =
                (SupportStreetViewPanoramaFragment)
                        getSupportFragmentManager()
                                .findFragmentById(
                                        R.id.streetViewContainer
                                );

        if (fragment != null) {
            fragment.getStreetViewPanoramaAsync(this);
        } else {
            mostrarErro("Não foi possível iniciar o Street View.");
        }
    }

    private boolean restaurarPartida() {
        GameDatabaseHelper db = new GameDatabaseHelper(this);
        try (Cursor cursor = db.obterPartidaEmCurso(partidaEmCursoId)) {
            if (!cursor.moveToFirst()) {
                return false;
            }

            JSONObject estado = new JSONObject(
                    cursor.getString(cursor.getColumnIndexOrThrow("estado"))
            );
            JSONArray ordemGuardada = estado.getJSONArray("ordem");
            for (int i = 0; i < ordemGuardada.length(); i++) {
                locais.add(ordemGuardada.getJSONObject(i));
            }

            indice = estado.getInt("indice");
            rondaAtual = estado.getInt("rondaAtual");
            pontosTotais = estado.getInt("pontosTotais");
            JSONArray resultadosGuardados = estado.getJSONArray("resultados");
            for (int i = 0; i < resultadosGuardados.length(); i++) {
                resultados.put(resultadosGuardados.getJSONObject(i));
            }

            panoAtualId = estado.optString("panoAtualId", null);
            if (panoAtualId != null && !panoAtualId.isEmpty()) {
                JSONObject esperada = estado.optJSONObject("coordenadaEsperada");
                if (esperada != null) {
                    coordenadaEsperada = new LatLng(
                            esperada.getDouble("latitude"),
                            esperada.getDouble("longitude")
                    );
                }

                JSONObject inicial = estado.optJSONObject("localizacaoInicial");
                if (inicial != null) {
                    localizacaoInicial = new LatLng(
                            inicial.getDouble("latitude"),
                            inicial.getDouble("longitude")
                    );
                }
                retomarRondaAtual = true;
            }

            return !locais.isEmpty();
        } catch (Exception e) {
            return false;
        } finally {
            db.close();
        }
    }

    private boolean carregarLocais() {
        try (InputStream entrada =
                     getAssets().open("locais_google.json")) {

            ByteArrayOutputStream saida =
                    new ByteArrayOutputStream();

            byte[] buffer = new byte[4096];
            int lidos;

            while ((lidos = entrada.read(buffer)) != -1) {
                saida.write(buffer, 0, lidos);
            }

            String conteudo = saida.toString("UTF-8");

            JSONArray array = new JSONArray(conteudo);

            for (int i = 0; i < array.length(); i++) {
                JSONObject local = array.getJSONObject(i);

                if (local.has("panoId")
                        && local.has("latitude")
                        && local.has("longitude")) {

                    locais.add(local);
                }
            }

            if (locais.size() < TOTAL_RONDAS) {
                mostrarErro(
                        "São necessários pelo menos 5 locais " +
                                "no ficheiro locais_google.json."
                );
                return false;
            }

            return true;

        } catch (Exception e) {
            mostrarErro(
                    "Erro ao carregar locais: " + e.getMessage()
            );
            return false;
        }
    }

    @Override
    public void onStreetViewPanoramaReady(
            StreetViewPanorama streetViewPanorama) {

        panorama = streetViewPanorama;

        panorama.setPanningGesturesEnabled(true);
        panorama.setZoomGesturesEnabled(true);
        panorama.setStreetNamesEnabled(false);
        panorama.setUserNavigationEnabled(false);

        panorama.setOnStreetViewPanoramaChangeListener(
                this::verificarPanorama
        );
        panorama.setOnStreetViewPanoramaCameraChangeListener(
                this::atualizarBussola
        );
        atualizarBussola(panorama.getPanoramaCamera());

        carregarRonda();
    }

    private void atualizarBussola(StreetViewPanoramaCamera camera) {
        if (camera != null && txtCompassNeedle != null) {
            txtCompassNeedle.setRotation(-camera.bearing);
        }
    }

    private void carregarRonda() {

        if (terminada || panorama == null) {
            return;
        }

        cancelarTimeout();

        boolean continuarRonda = retomarRondaAtual
                && panoAtualId != null
                && coordenadaEsperada != null;

        localPronto = false;
        aCarregar = false;
        if (!continuarRonda) {
            localizacaoInicial = null;
            coordenadaEsperada = null;
        }

        btnAdivinhar.setEnabled(false);
        panorama.setUserNavigationEnabled(false);

        JSONObject local;
        if (continuarRonda) {
            retomarRondaAtual = false;
            local = null;
        } else {
            if (indice >= locais.size()) {
                mostrarErro(
                        "Não existem mais localizações válidas. " +
                                "Atualiza a lista de locais."
                );
                return;
            }

            try {
                local = locais.get(indice++);
                panoAtualId = local.getString("panoId");
                coordenadaEsperada = new LatLng(
                        local.getDouble("latitude"),
                        local.getDouble("longitude")
                );
            } catch (Exception e) {
                mostrarErro("Erro ao preparar localização.");
                return;
            }
        }

        if (local == null && (panoAtualId == null
                || coordenadaEsperada == null)) {
            mostrarErro(
                    "Não existem mais localizações válidas. " +
                            "Atualiza a lista de locais."
            );
            return;
        }

        try {
            aCarregar = true;

            txtEstado.setText(
                    "Ronda " + rondaAtual + "/5\n" +
                            "A carregar estrada..."
            );

            // Abrir precisamente o panorama oficial
            // selecionado na preparação das localizações.
            panorama.setPosition(panoAtualId);
            guardarPartidaEmCurso();

            timeoutAtual = () -> {
                if (aCarregar && !localPronto && !terminada) {
                    carregarRonda();
                }
            };

            handler.postDelayed(timeoutAtual, 12000);

        } catch (Exception e) {
            mostrarErro("Erro ao abrir localização.");
        }
    }

    private void verificarPanorama(
            StreetViewPanoramaLocation location) {

        if (!aCarregar || localPronto || terminada) {
            return;
        }

        if (location == null
                || location.position == null
                || coordenadaEsperada == null) {

            tentarOutroLocal();
            return;
        }

        // Confirmar que não foi carregado um
        // panorama muito afastado do esperado.
        float[] distancia = new float[1];

        Location.distanceBetween(
                coordenadaEsperada.latitude,
                coordenadaEsperada.longitude,
                location.position.latitude,
                location.position.longitude,
                distancia
        );

        if (distancia[0] > 100) {
            return;
        }

        // Exigir ligação a outras vistas da estrada.
        if (location.links == null
                || location.links.length < 2) {

            tentarOutroLocal();
            return;
        }

        cancelarTimeout();

        localizacaoInicial = location.position;

        localPronto = true;
        aCarregar = false;

        panorama.setUserNavigationEnabled(true);
        btnAdivinhar.setEnabled(true);

        atualizarEstado();
    }

    private void tentarOutroLocal() {
        cancelarTimeout();
        aCarregar = false;
        handler.post(this::carregarRonda);
    }

    private void alterarZoom(float diferenca) {

        if (panorama == null || !localPronto) {
            return;
        }

        StreetViewPanoramaCamera camera =
                panorama.getPanoramaCamera();

        if (camera == null) {
            return;
        }

        float zoom = Math.max(
                0f,
                Math.min(5f, camera.zoom + diferenca)
        );

        StreetViewPanoramaCamera novaCamera =
                new StreetViewPanoramaCamera.Builder()
                        .zoom(zoom)
                        .tilt(camera.tilt)
                        .bearing(camera.bearing)
                        .build();

        panorama.animateTo(novaCamera, 250);
    }

    private void atualizarEstado() {

        txtEstado.setText(
                String.format(
                        Locale.getDefault(),
                        "Ronda %d/5 | %d pontos",
                        rondaAtual,
                        pontosTotais
                )
        );
    }

    private void guardarPartidaEmCurso() {
        if (terminada || locais.isEmpty()) {
            return;
        }

        try {
            JSONArray ordem = new JSONArray();
            for (JSONObject local : locais) {
                ordem.put(local);
            }

            JSONObject estado = new JSONObject();
            estado.put("indice", indice);
            estado.put("rondaAtual", rondaAtual);
            estado.put("pontosTotais", pontosTotais);
            estado.put("ordem", ordem);
            estado.put("resultados", new JSONArray(resultados.toString()));
            estado.put("panoAtualId", panoAtualId);

            if (coordenadaEsperada != null) {
                estado.put("coordenadaEsperada", coordenadaJson(
                        coordenadaEsperada
                ));
            }
            if (localizacaoInicial != null) {
                estado.put("localizacaoInicial", coordenadaJson(
                        localizacaoInicial
                ));
            }

            GameDatabaseHelper db = new GameDatabaseHelper(this);
            try {
                partidaEmCursoId = db.guardarPartidaEmCurso(
                        partidaEmCursoId,
                        "Mundo Online",
                        estado
                );
            } finally {
                db.close();
            }
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Não foi possível guardar a partida em curso.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private JSONObject coordenadaJson(LatLng coordenada)
            throws org.json.JSONException {
        JSONObject json = new JSONObject();
        json.put("latitude", coordenada.latitude);
        json.put("longitude", coordenada.longitude);
        return json;
    }

    private void voltarAoMenuPrincipal() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void abrirPalpite() {

        if (!localPronto
                || localizacaoInicial == null
                || terminada) {
            return;
        }

        Intent intent = new Intent(
                this,
                OnlineGuessActivity.class
        );

        intent.putExtra(
                "latitude",
                localizacaoInicial.latitude
        );

        intent.putExtra(
                "longitude",
                localizacaoInicial.longitude
        );

        intent.putExtra("ronda", rondaAtual);
        if (estadoMapaPalpite != null) {
            intent.putExtras(estadoMapaPalpite);
        }

        abrirMapa.launch(intent);
    }

    private void guardarRonda(Intent data) {

        if (terminada || !localPronto) {
            return;
        }

        int pontos = data.getIntExtra("pontos", 0);

        double distancia = data.getDoubleExtra(
                "distancia", 0
        );

        try {
            JSONObject registo = new JSONObject();

            registo.put("ronda", rondaAtual);

            registo.put(
                    "latitudeCorreta",
                    localizacaoInicial.latitude
            );

            registo.put(
                    "longitudeCorreta",
                    localizacaoInicial.longitude
            );

            registo.put(
                    "latitudePalpite",
                    data.getDoubleExtra("latitudePalpite", 0)
            );

            registo.put(
                    "longitudePalpite",
                    data.getDoubleExtra("longitudePalpite", 0)
            );

            registo.put("distancia", distancia);
            registo.put("pontos", pontos);

            resultados.put(registo);

            pontosTotais += pontos;

        } catch (Exception e) {
            mostrarErro("Erro ao registar o resultado.");
            return;
        }

        if (rondaAtual == TOTAL_RONDAS) {
            terminarPartida();
        } else {
            rondaAtual++;
            carregarRonda();
        }
    }

    private void terminarPartida() {

        terminada = true;
        cancelarTimeout();

        btnAdivinhar.setEnabled(false);

        GameDatabaseHelper db =
                new GameDatabaseHelper(this);

        long id = db.guardarPartida(
                "Mundo Online",
                pontosTotais,
                resultados
        );
        db.eliminarPartidaEmCurso(partidaEmCursoId);
        db.close();

        String mensagem = String.format(
                Locale.getDefault(),
                "Pontuação final: %d / 25000\n\n%s",
                pontosTotais,
                id >= 0
                        ? "Partida guardada no histórico."
                        : "Erro ao guardar a partida."
        );

        new AlertDialog.Builder(this)
                .setTitle("Fim da partida!")
                .setMessage(mensagem)
                .setPositiveButton(
                        "Voltar ao menu",
                        (dialog, which) -> finish()
                )
                .setCancelable(false)
                .show();
    }

    private void cancelarTimeout() {
        if (timeoutAtual != null) {
            handler.removeCallbacks(timeoutAtual);
            timeoutAtual = null;
        }
    }

    private void mostrarErro(String mensagem) {
        new AlertDialog.Builder(this)
                .setTitle("GeoChallenge")
                .setMessage(mensagem)
                .setPositiveButton(
                        "Voltar",
                        (dialog, which) -> finish()
                )
                .setCancelable(false)
                .show();
    }

    @Override
    protected void onDestroy() {
        cancelarTimeout();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        guardarPartidaEmCurso();
        super.onPause();
    }
}
