package com.example.geochallenge;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class OnlineGuessActivity extends AppCompatActivity
        implements OnMapReadyCallback {

    private GoogleMap googleMap;
    private LatLng localizacaoCorreta;
    private LatLng palpite;

    private Marker marcadorPalpite;

    private Button btnConfirmar;
    private Button btnVoltar;

    private TextView txtInfo;
    private TextView txtResultado;
    private TextView txtTitulo;

    private boolean respondeu = false;
    private int rondaAtual;

    private static final String EXTRA_MAP_CENTER_LATITUDE =
            "mapCenterLatitude";
    private static final String EXTRA_MAP_CENTER_LONGITUDE =
            "mapCenterLongitude";
    private static final String EXTRA_MAP_ZOOM = "mapZoom";
    private static final String EXTRA_HAS_GUESS = "mapHasGuess";
    private static final String EXTRA_GUESS_LATITUDE = "mapGuessLatitude";
    private static final String EXTRA_GUESS_LONGITUDE = "mapGuessLongitude";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_online_guess);

        double latitude = getIntent().getDoubleExtra(
                "latitude", 40.7580);

        double longitude = getIntent().getDoubleExtra(
                "longitude", -73.9855);

        rondaAtual = getIntent().getIntExtra(
                "ronda", 1);

        localizacaoCorreta = new LatLng(
                latitude, longitude);

        btnConfirmar = findViewById(
                R.id.btnConfirmarOnline);

        btnVoltar = findViewById(
                R.id.btnVoltarStreetView);

        txtInfo = findViewById(
                R.id.txtInfoMapa);

        txtResultado = findViewById(
                R.id.txtResultado);

        txtTitulo = findViewById(
                R.id.txtTituloMapa);

        txtTitulo.setText(
                getString(R.string.guess_title, rondaAtual)
        );

        btnConfirmar.setEnabled(false);

        btnConfirmar.setOnClickListener(v -> {
            if (respondeu) {
                finish();
            } else {
                confirmarPalpite();
            }
        });

        btnVoltar.setOnClickListener(v -> devolverAoJogo());

        SupportMapFragment fragment =
                (SupportMapFragment)
                        getSupportFragmentManager()
                                .findFragmentById(
                                        R.id.googleMapContainer);

        if (fragment != null) {
            fragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap map) {

        googleMap = map;

        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        googleMap.getUiSettings()
                .setZoomControlsEnabled(true);

        googleMap.getUiSettings()
                .setZoomGesturesEnabled(true);

        googleMap.getUiSettings()
                .setScrollGesturesEnabled(true);

        googleMap.getUiSettings()
                .setRotateGesturesEnabled(false);

        googleMap.getUiSettings()
                .setTiltGesturesEnabled(false);

        boolean estadoAnterior = getIntent().hasExtra(
                EXTRA_MAP_CENTER_LATITUDE
        );
        LatLng centro = estadoAnterior
                ? new LatLng(
                        getIntent().getDoubleExtra(
                                EXTRA_MAP_CENTER_LATITUDE, 15
                        ),
                        getIntent().getDoubleExtra(
                                EXTRA_MAP_CENTER_LONGITUDE, 0
                        )
                )
                : new LatLng(15, 0);
        float zoom = getIntent().getFloatExtra(EXTRA_MAP_ZOOM, 2f);
        googleMap.moveCamera(
                CameraUpdateFactory.newLatLngZoom(centro, zoom)
        );

        if (getIntent().getBooleanExtra(EXTRA_HAS_GUESS, false)) {
            palpite = new LatLng(
                    getIntent().getDoubleExtra(EXTRA_GUESS_LATITUDE, 0),
                    getIntent().getDoubleExtra(EXTRA_GUESS_LONGITUDE, 0)
            );
            marcadorPalpite = googleMap.addMarker(
                    new MarkerOptions()
                            .position(palpite)
                            .title("O teu palpite")
                            .icon(BitmapDescriptorFactory.defaultMarker(
                                    BitmapDescriptorFactory.HUE_RED))
            );
            btnConfirmar.setEnabled(true);
            txtInfo.setText(R.string.guess_selected);
        }

        googleMap.setOnMapClickListener(local -> {

            if (respondeu) {
                return;
            }

            palpite = local;

            if (marcadorPalpite != null) {
                marcadorPalpite.remove();
            }

            marcadorPalpite = googleMap.addMarker(
                    new MarkerOptions()
                            .position(palpite)
                            .title("O teu palpite")
                            .icon(BitmapDescriptorFactory.defaultMarker(
                                    BitmapDescriptorFactory.HUE_RED))
            );

            btnConfirmar.setEnabled(true);

            txtInfo.setText(
                    R.string.guess_selected
            );
        });
    }

    private void confirmarPalpite() {

        if (palpite == null || respondeu) {
            Toast.makeText(this,
                    "Seleciona primeiro um local",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        respondeu = true;

        float[] distancias = new float[1];

        Location.distanceBetween(
                palpite.latitude,
                palpite.longitude,
                localizacaoCorreta.latitude,
                localizacaoCorreta.longitude,
                distancias
        );

        double distanciaKm = distancias[0] / 1000.0;

        int pontos = (int) Math.round(
                5000 * Math.exp(-distanciaKm / 2000.0)
        );

        pontos = Math.max(
                0, Math.min(5000, pontos)
        );

        // Mostrar a localização correta.
        googleMap.addMarker(
                new MarkerOptions()
                        .position(localizacaoCorreta)
                        .title("Localização correta")
                        .icon(BitmapDescriptorFactory.defaultMarker(
                                BitmapDescriptorFactory.HUE_GREEN))
        );

        // Linha entre a resposta e o palpite.
        googleMap.addPolyline(
                new PolylineOptions()
                        .add(palpite, localizacaoCorreta)
                        .width(5f)
                        .color(Color.RED)
        );

        LatLngBounds limites = new LatLngBounds.Builder()
                .include(palpite)
                .include(localizacaoCorreta)
                .build();

        googleMap.animateCamera(
                CameraUpdateFactory.newLatLngBounds(
                        limites, 100
                )
        );

        txtResultado.setText(
                getString(R.string.guess_result, distanciaKm, pontos)
        );
        txtResultado.setVisibility(View.VISIBLE);

        txtInfo.setVisibility(View.GONE);

        btnConfirmar.setText(
                rondaAtual == 5 ?
                        R.string.offline_terminar : R.string.offline_proxima
        );

        btnConfirmar.setEnabled(true);

        btnVoltar.setVisibility(View.GONE);

        // Entregar o resultado à Activity do jogo.
        Intent resultado = new Intent();

        resultado.putExtra("pontos", pontos);
        resultado.putExtra("distancia", distanciaKm);

        resultado.putExtra(
                "latitudePalpite",
                palpite.latitude
        );

        resultado.putExtra(
                "longitudePalpite",
                palpite.longitude
        );

        setResult(Activity.RESULT_OK, resultado);
    }

    private void devolverAoJogo() {
        if (respondeu || googleMap == null) {
            finish();
            return;
        }

        com.google.android.gms.maps.model.CameraPosition camera =
                googleMap.getCameraPosition();
        Intent estado = new Intent();
        estado.putExtra(
                EXTRA_MAP_CENTER_LATITUDE,
                camera.target.latitude
        );
        estado.putExtra(
                EXTRA_MAP_CENTER_LONGITUDE,
                camera.target.longitude
        );
        estado.putExtra(EXTRA_MAP_ZOOM, camera.zoom);
        estado.putExtra(EXTRA_HAS_GUESS, palpite != null);
        if (palpite != null) {
            estado.putExtra(EXTRA_GUESS_LATITUDE, palpite.latitude);
            estado.putExtra(EXTRA_GUESS_LONGITUDE, palpite.longitude);
        }
        setResult(Activity.RESULT_CANCELED, estado);
        finish();
    }

    @Override
    public void onBackPressed() {
        devolverAoJogo();
    }

}
