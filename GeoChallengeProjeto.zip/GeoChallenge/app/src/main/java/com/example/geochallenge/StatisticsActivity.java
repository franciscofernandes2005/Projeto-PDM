package com.example.geochallenge;

import android.os.Bundle;
import android.database.sqlite.SQLiteException;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
import java.util.Map;

public class StatisticsActivity extends AppCompatActivity {

    private TextView resumoGeral;
    private TextView resumoModos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        resumoGeral = findViewById(R.id.txtEstatisticasGeral);
        resumoModos = findViewById(R.id.txtEstatisticasModos);
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizarEstatisticas();
    }

    private void atualizarEstatisticas() {
        try (GameDatabaseHelper db = new GameDatabaseHelper(this)) {
            GameDatabaseHelper.Estatisticas estatisticas =
                    db.obterEstatisticas();

            if (estatisticas.partidas == 0) {
                resumoGeral.setText(R.string.estatisticas_sem_dados);
                resumoModos.setText("");
                return;
            }

            resumoGeral.setText(String.format(
                    Locale.getDefault(),
                    "%s\n%s\n%s",
                    getString(
                            R.string.estatisticas_total_partidas,
                            estatisticas.partidas
                    ),
                    getString(
                            R.string.estatisticas_pontuacao_media,
                            estatisticas.pontuacaoMedia()
                    ),
                    estatisticas.rondasComDistancia == 0
                            ? getString(R.string.estatisticas_sem_distancias)
                            : getString(
                                    R.string.estatisticas_distancia_media,
                                    estatisticas.distanciaMediaKm()
                            )
            ));

            StringBuilder porModo = new StringBuilder();
            for (Map.Entry<String, GameDatabaseHelper.EstatisticasModo> entrada
                    : estatisticas.porModo.entrySet()) {
                GameDatabaseHelper.EstatisticasModo modo = entrada.getValue();
                if (porModo.length() > 0) {
                    porModo.append("\n\n");
                }
                porModo.append(getString(
                        R.string.estatisticas_resumo_modo,
                        entrada.getKey(),
                        modo.partidas,
                        modo.pontuacaoMedia()
                ));
                porModo.append('\n');
                porModo.append(modo.rondasComDistancia == 0
                        ? getString(R.string.estatisticas_sem_distancias)
                        : getString(
                                R.string.estatisticas_distancia_media,
                                modo.distanciaMediaKm()
                        ));
            }
            resumoModos.setText(porModo.toString());
        } catch (SQLiteException e) {
            resumoGeral.setText(R.string.estatisticas_erro);
            resumoModos.setText("");
        }
    }
}
