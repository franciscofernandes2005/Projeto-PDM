package com.example.geochallenge;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnJogar = findViewById(R.id.btnJogar);
        Button btnHistorico = findViewById(R.id.btnHistorico);
        Button btnEstatisticas = findViewById(R.id.btnEstatisticas);

        // Abrir a seleção de desafios.
        btnJogar.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this,
                    ModeActivity.class
            );

            startActivity(intent);
        });

        // Consultar as partidas guardadas.
        btnHistorico.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this,
                    HistoryActivity.class
            );

            startActivity(intent);
        });

        btnEstatisticas.setOnClickListener(v -> {
            startActivity(new Intent(this, StatisticsActivity.class));
        });
    }
}
