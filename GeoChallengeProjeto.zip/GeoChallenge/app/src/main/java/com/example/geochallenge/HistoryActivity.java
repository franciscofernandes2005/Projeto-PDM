package com.example.geochallenge;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {

    private static final int TAB_CONCLUIDAS = 0;
    private static final int TAB_EM_CURSO = 1;

    private GameDatabaseHelper db;
    private ListView lista;
    private Button btnConcluidas;
    private Button btnEmCurso;
    private int separadorAtivo = TAB_CONCLUIDAS;

    private final ArrayList<Partida> partidas = new ArrayList<>();
    private final ArrayList<String> textos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new GameDatabaseHelper(this);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        TextView titulo = new TextView(this);
        titulo.setText(R.string.historico);
        titulo.setTextSize(24);
        titulo.setPadding(8, 8, 8, 16);
        layout.addView(titulo);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);

        btnConcluidas = new Button(this);
        btnConcluidas.setText(R.string.historico_concluidas);
        tabs.addView(
                btnConcluidas,
                new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1)
        );

        btnEmCurso = new Button(this);
        btnEmCurso.setText(R.string.historico_em_curso);
        tabs.addView(
                btnEmCurso,
                new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1)
        );

        layout.addView(tabs);

        lista = new ListView(this);
        layout.addView(
                lista,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        0,
                        1
                )
        );

        setContentView(layout);

        btnConcluidas.setOnClickListener(v -> selecionarSeparador(TAB_CONCLUIDAS));
        btnEmCurso.setOnClickListener(v -> selecionarSeparador(TAB_EM_CURSO));

        lista.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= partidas.size()) {
                return;
            }
            if (separadorAtivo == TAB_EM_CURSO) {
                mostrarAcoesPartidaEmCurso(partidas.get(position));
            } else {
                mostrarDetalhes(partidas.get(position));
            }
        });

        lista.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position < partidas.size()) {
                Partida partida = partidas.get(position);
                if (separadorAtivo == TAB_EM_CURSO) {
                    confirmarEliminacaoEmCurso(partida);
                } else {
                    confirmarEliminacaoConcluida(partida);
                }
            }
            return true;
        });

        selecionarSeparador(TAB_CONCLUIDAS);
    }

    private void selecionarSeparador(int separador) {
        separadorAtivo = separador;
        btnConcluidas.setEnabled(separador != TAB_CONCLUIDAS);
        btnEmCurso.setEnabled(separador != TAB_EM_CURSO);
        carregarPartidas();
    }

    private void carregarPartidas() {
        partidas.clear();
        textos.clear();

        if (separadorAtivo == TAB_CONCLUIDAS) {
            carregarConcluidas();
        } else {
            carregarEmCurso();
        }

        if (textos.isEmpty()) {
            textos.add(getString(
                    separadorAtivo == TAB_CONCLUIDAS
                            ? R.string.historico_vazio_concluidas
                            : R.string.historico_vazio_em_curso
            ));
        }

        lista.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                textos
        ));
    }

    private void carregarConcluidas() {
        try (Cursor cursor = db.listarPartidas()) {
            while (cursor.moveToNext()) {
                Partida partida = new Partida(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("data")),
                        cursor.getString(cursor.getColumnIndexOrThrow("modo")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("pontuacao")),
                        cursor.getString(cursor.getColumnIndexOrThrow("detalhes"))
                );
                partidas.add(partida);
                textos.add(
                        partida.modo + "\n" + partida.data + "\n" +
                                "Pontuação: " + partida.pontos + " / 25000"
                );
            }
        }
    }

    private void carregarEmCurso() {
        try (Cursor cursor = db.listarPartidasEmCurso()) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String data = cursor.getString(cursor.getColumnIndexOrThrow("data"));
                String modo = cursor.getString(cursor.getColumnIndexOrThrow("modo"));
                String estado = cursor.getString(cursor.getColumnIndexOrThrow("estado"));

                int ronda = 1;
                int pontos = 0;
                try {
                    JSONObject json = new JSONObject(estado);
                    ronda = json.optInt("rondaAtual", 1);
                    pontos = json.optInt("pontosTotais", 0);
                } catch (Exception e) {
                    // A partida inválida continua disponível para ser eliminada.
                }

                partidas.add(new Partida(id, data, modo, pontos, estado));
                textos.add(
                        modo + "\n" + data + "\n" +
                                getString(R.string.historico_ronda_estado, ronda, pontos)
                );
            }
        }
    }

    private void mostrarDetalhes(Partida partida) {
        StringBuilder mensagem = new StringBuilder();

        try {
            JSONArray rondas = new JSONArray(partida.detalhes);
            for (int i = 0; i < rondas.length(); i++) {
                JSONObject ronda = rondas.getJSONObject(i);
                String local = ronda.optString("nome", "");
                String pais = ronda.optString("pais", "");
                if (!local.isEmpty()) {
                    mensagem.append(local);
                    if (!pais.isEmpty()) {
                        mensagem.append(" — ").append(pais);
                    }
                    mensagem.append('\n');
                }
                mensagem.append(String.format(
                        Locale.getDefault(),
                        "Ronda %d\nDistância: %.1f km\nPontos: %d / 5000\n\n",
                        ronda.getInt("ronda"),
                        ronda.getDouble("distancia"),
                        ronda.getInt("pontos")
                ));
            }
        } catch (Exception e) {
            mensagem.append("Erro ao ler as rondas.");
        }

        new AlertDialog.Builder(this)
                .setTitle("Detalhes da partida")
                .setMessage(mensagem.toString())
                .setPositiveButton("Fechar", null)
                .show();
    }

    private void mostrarAcoesPartidaEmCurso(Partida partida) {
        new AlertDialog.Builder(this)
                .setTitle(partida.modo)
                .setMessage(R.string.historico_acao_em_curso)
                .setPositiveButton(
                        R.string.historico_continuar,
                        (dialog, which) -> continuarPartida(partida)
                )
                .setNegativeButton(
                        R.string.historico_eliminar,
                        (dialog, which) -> confirmarEliminacaoEmCurso(partida)
                )
                .setNeutralButton("Cancelar", null)
                .show();
    }

    private void continuarPartida(Partida partida) {
        Class<?> activity = "Mundo Online".equals(partida.modo)
                ? OnlineGameActivity.class
                : OfflineGameActivity.class;
        Intent intent = new Intent(this, activity);
        intent.putExtra("partidaEmCursoId", partida.id);
        intent.putExtra(
                "locaisFamosos",
                "Locais Famosos".equals(partida.modo)
        );
        startActivity(intent);
    }

    private void confirmarEliminacaoConcluida(Partida partida) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar partida")
                .setMessage("Tens a certeza de que queres eliminar esta partida?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    db.eliminarPartida(partida.id);
                    carregarPartidas();
                })
                .show();
    }

    private void confirmarEliminacaoEmCurso(Partida partida) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.historico_eliminar)
                .setMessage(R.string.historico_eliminar_confirmacao)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton(R.string.historico_eliminar, (dialog, which) -> {
                    db.eliminarPartidaEmCurso(partida.id);
                    carregarPartidas();
                })
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (lista != null) {
            carregarPartidas();
        }
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }

    private static final class Partida {
        final long id;
        final String data;
        final String modo;
        final int pontos;
        final String detalhes;

        Partida(long id, String data, String modo, int pontos, String detalhes) {
            this.id = id;
            this.data = data;
            this.modo = modo;
            this.pontos = pontos;
            this.detalhes = detalhes;
        }
    }
}
