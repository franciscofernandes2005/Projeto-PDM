package com.example.geochallenge;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public final class OfflinePlacesRepository {

    public static final class Local {

        public final int id;
        public final String nome;
        public final String pais;
        public final String imagem;
        public final String caminhoImagem;
        public final String autor;
        public final String licenca;
        public final String fonte;
        public final double latitude;
        public final double longitude;

        Local(JSONObject json, String pastaImagens) throws Exception {

            id = json.getInt("id");
            nome = json.getString("nome");
            pais = json.getString("pais");
            imagem = json.getString("imagem");
            autor = json.optString("autor", "");
            licenca = json.optString("licenca", "");
            fonte = json.optString("fonte", "");
            latitude = json.getDouble("latitude");
            longitude = json.getDouble("longitude");

            if (latitude < -90 || latitude > 90 ||
                    longitude < -180 || longitude > 180) {

                throw new IllegalArgumentException(
                        "Coordenadas inválidas: " + id
                );
            }

            if (!imagem.matches("(local|famous)_[0-9]{2}\\.jpg")) {
                throw new IllegalArgumentException(
                        "Imagem inválida: " + imagem
                );
            }

            caminhoImagem = pastaImagens + "/" + imagem;
        }
    }

    private OfflinePlacesRepository() {
    }

    public static ArrayList<Local> carregar(
            Context context) throws Exception {
        return carregar(context, "offline_locais.json", "offline_360", 20);
    }

    public static ArrayList<Local> carregarLocaisFamosos(
            Context context) throws Exception {
        return carregar(context, "locais_famosos.json", "famous_360", 5);
    }

    private static ArrayList<Local> carregar(
            Context context,
            String ficheiroLocais,
            String pastaImagens,
            int totalEsperado) throws Exception {

        ByteArrayOutputStream saida =
                new ByteArrayOutputStream();

        byte[] buffer = new byte[8192];

        try (InputStream entrada =
                     context.getAssets().open(
                             ficheiroLocais)) {

            int lidos;

            while ((lidos = entrada.read(buffer)) != -1) {
                saida.write(buffer, 0, lidos);
            }
        }

        JSONArray dados = new JSONArray(
                saida.toString("UTF-8")
        );

        if (dados.length() < totalEsperado) {
            throw new IOException(
                    "São necessários pelo menos " + totalEsperado
                            + " locais. Encontrados: "
                            + dados.length()
            );
        }

        ArrayList<Local> locais = new ArrayList<>();

        for (int i = 0; i < dados.length(); i++) {

            Local local = new Local(dados.getJSONObject(i), pastaImagens);

            try (InputStream imagem =
                         context.getAssets().open(local.caminhoImagem)) {

                locais.add(local);
            }
        }

        return locais;
    }
}
